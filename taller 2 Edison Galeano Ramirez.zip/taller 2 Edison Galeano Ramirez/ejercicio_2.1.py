

direccion = input("ingrese la direccion: ")
bestia = input("digite el nombre de la bestia: ")
i = 1
while i <= 3:
        if direccion == ("babor") and bestia == "kraken":
            print(f"¡ahoy! Capitan un {bestia} a {direccion}")
        else:
            if direccion == ("estribor") and bestia == "kraken":
                print(f"¡ahoy! Capitan un {bestia} a {direccion}")
            else:
                if direccion == ("proa") and bestia == "kraken":
                    print(f"¡ahoy! Capitan un {bestia} a {direccion}")
                else:
                    if direccion == ("popa") and bestia == "kraken":
                        print(f"¡ahoy! Capitan un {bestia} a {direccion}")
                    else:
                        if direccion == ("babor") and bestia == "sirenas":
                            print(f"¡ahoy! Capitan unas {bestia} a {direccion}")
                        else:
                            if direccion == ("estribor") and bestia == "sirenas":
                                print(f"¡ahoy! Capitan unas {bestia} a {direccion}")
                            else:
                                if direccion == ("proa") and bestia == "sirenas":
                                    print(f"¡ahoy! Capitan unas {bestia} a {direccion}")
                                else:
                                    if direccion == ("popa") and bestia == "sirenas":
                                        print(f"¡ahoy! Capitan unas {bestia} a {direccion}")
                                    else:
                                        if direccion == ("babor") and bestia == "ballena":
                                            print(f"¡ahoy! Capitan una {bestia} a {direccion}")
                                        else:
                                            if direccion == ("estribor") and bestia == "ballena":
                                                print(f"¡ahoy! Capitan una {bestia} a {direccion}")
                                            else:
                                                if direccion == ("popa") and bestia == "ballena":
                                                    print(f"¡ahoy! Capitan una {bestia} a {direccion}")
                                                else:
                                                    if direccion == ("proa") and bestia == "ballena":
                                                        print(f"¡ahoy! Capitan una {bestia} a {direccion}")
                                                    else:
                                                        if direccion == ("babor") and bestia == "hipocampo":
                                                            print(f"¡ahoy! Capitan un {bestia} a {direccion}")
                                                        else:
                                                            if direccion == ("estribor") and bestia == "hipocampo":
                                                                print(f"¡ahoy! Capitan un {bestia} a {direccion}")
                                                            else:
                                                                if direccion == ("proa") and bestia == "hipocampo":
                                                                    print(f"¡ahoy! Capitan un {bestia} a {direccion}")
                                                                else:
                                                                    if direccion == ("babor") and bestia == "macaraprono":
                                                                        print(f"¡ahoy! Capitan una {bestia} a {direccion}")
                                                                    else:
                                                                        if direccion == (
                                                                        "estribor") and bestia == "macaraprono":
                                                                            print(
                                                                                f"¡ahoy! Capitan una {bestia} a {direccion}")
                                                                        else:
                                                                            if direccion == (
                                                                            "proa") and bestia == "macaraprono":
                                                                                print(
                                                                                    f"¡ahoy! Capitan una {bestia} a {direccion}")
                                                                            else:
                                                                                if direccion == (
                                                                                "popa") and bestia == "macaraprono":
                                                                                    print(
                                                                                        f"¡ahoy! Capitan una {bestia} a {direccion}")
                                                                                else:
                                                                                    if direccion == (
                                                                                    "babor") and bestia == "macaraprono":
                                                                                        print(
                                                                                            f"¡ahoy! Capitan una {bestia} a {direccion}")

                                                                                        i += 1




