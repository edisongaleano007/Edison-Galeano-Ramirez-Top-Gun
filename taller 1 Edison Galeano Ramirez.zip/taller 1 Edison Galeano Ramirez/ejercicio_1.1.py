print("     /?\   ")
print("    |00 ) .")
print("     \=/")
print("    _   _")
print("   /     \ ")
print("  /   _   \ ")
print(" //|/ . \|\\    ")
print(" \\ \ _ /  ||   ")
print("  \|\   /| ||  ")
print("  #  _ _ /  #  ")
print("   |  |  | ")
print("   |  |  |")
print("   [] | []")
print("   |  |  |")
print("  /  ] [  \ ")




