""" for this exercise i am missing the parentheses"""
number_1 = 10
number_2 = 20
number_3 = 6.5

media = (number_1 + number_2 + number_3) / 3
print(f"{media} es la media.")

""" el punto 5"""
nota_1 = input("Ingresar nota 1: ")
nota_2 = input("Ingresar nota 2: ")
nota_3 = input("Ingresar nota 3: ")

print("el promedio de los datos leidos son: " + str((number_1 + number_2 + number_3) / 3))

